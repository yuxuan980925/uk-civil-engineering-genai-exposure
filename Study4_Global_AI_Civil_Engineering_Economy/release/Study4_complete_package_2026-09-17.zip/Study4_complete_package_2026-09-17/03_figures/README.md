# Figures

- `figure10_instruments_vs_aps.png`
- `figure11_aiie_construction.png`
- `figure12_tnlg_vs_tml.png`
- `figure13_tnlg_2024_MF.png`
- `figure14_event_study_tnlg.png`
- `figure15_cross_section_tnlg.png`
- `figure16_tnlg_by_nace.png`
- `figure1_eurostat_M_vs_F.png`
- `figure2_uk_aps_bundle.png`
- `figure3_uk_trade.png`
- `figure4_event_study.png`
- `figure5_ilo_M_vs_F.png`
- `figure6_eu_mode1_vs_china.png`
- `figure7_cross_section.png`
- `figure8_loo.png`
- `figure9_m71_vs_F_gva.png`
