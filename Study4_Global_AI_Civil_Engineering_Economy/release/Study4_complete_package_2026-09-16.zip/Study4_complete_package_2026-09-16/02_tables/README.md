# Tables

- `table_ai_intensity.csv`
- `table_batis_corridors.csv`
- `table_cross_section_india.csv`
- `table_eloundou_civil.csv`
- `table_eurostat_M_F.csv`
- `table_event_study.csv`
- `table_identification.csv`
- `table_ilo_FM.csv`
- `table_loo_importer.csv`
- `table_m71_emp_pct_2019_2023.csv`
- `table_m71_gva_pct_2019_2023.csv`
- `table_novelty_m71_sj2.csv`
- `table_uk_aps_change.csv`
- `table_uk_aps_civil_bundle.csv`
- `table_uk_aps_vs_india_sj3.csv`
- `table_world_bank.csv`
