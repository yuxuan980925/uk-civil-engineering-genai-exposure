# How Does the Civil Engineering Industry Economy Change under an AI Shock?

Evidence from a Cross-Country Stack — **complete article folder**

**Open in the editor (not the zip):**

- `OPEN_IN_EDITOR.md` — this folder’s entry list
- `Study4_Manuscript.md` — full English article
- `CN_full_article.md` — Chinese article
- `tables_for_article.md` — all article tables
- `FIGURES.md` — figures 1–21
- `figures/` — PNG files
- `tables/` — CSV tables
- `data/` — official series used in the paper
- `index.html` — compiled HTML (figures load from `figures/`)

Zip in this folder: **`Study4.zip`**

Unzip with Finder / Explorer. After unzip you should see `Study4_Manuscript.md` at the top. Cursor cannot preview zip files.
