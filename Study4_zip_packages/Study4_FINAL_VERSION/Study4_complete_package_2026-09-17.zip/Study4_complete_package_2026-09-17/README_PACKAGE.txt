Study 4 complete package
========================
Built: 2026-09-17

Open the git folder Study4_FINAL_VERSION/ (data/, tables/, figures/, manuscript/, scripts/).
This zip uses numbered folders for a portable snapshot.

00_previous_ijcm_data/  Occupation-paper files (Felten, ONS, APS, LLM panel). LLM scores are NOT the shock.
01_data/         Official Study 4 downloads + analysis panels (no fabricated cells)
02_tables/       All regression and descriptive tables (CSV)
03_figures/      All figures 1-21 (PNG)
04_manuscript/   Full English article + Chinese full article + tables
05_scripts/      Replication scripts

How to replicate (from Study4_FINAL_VERSION/)
---------------------------------------------
python3 scripts/run_analysis.py
python3 scripts/run_novelty_layer.py
python3 scripts/run_nlg_shock.py
python3 scripts/run_industry_economy.py

Do not treat APS SOC 2121 as causing partner-country GDP.
NACE M71 AI survey and BaTIS SJ312 do not exist.
