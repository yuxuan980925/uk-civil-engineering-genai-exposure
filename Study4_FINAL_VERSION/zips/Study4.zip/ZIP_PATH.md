Complete Study 4 zip (download and unzip locally; do not open in the editor):

- `Study4_Global_AI_Civil_Engineering_Economy/Study4.zip`
- `Study4_zip_packages/Study4.zip`
- `Study4_zip_packages/Study4_complete_package_2026-09-18.zip`

After unzipping, `Study4_Manuscript.md` is at the top of the archive.
